# encoding: ASCII
# null.rb
# @Author:      Thomas Link (micathom AT gmail com)
# @Website:     http://deplate.sf.net/
# @License:     GPL (see http://www.gnu.org/licenses/gpl.txt)
# @Created:     17-M�r-2004.
# @Last Change: 2009-02-02.
# @Revision:    0.3749

require 'deplate/formatter'

class Deplate::Formatter::NULL < Deplate::Formatter
    self.myname = 'null'
    self.rx     = /null?/i
    
    def format_particle(agent, invoker, *args)
        ''
    end

    def format_element(agent, invoker, *args)
        ''
    end

    def output(invoker, *body)
    end
end


class Deplate::Core
    def body_write
    end
end

