# encoding: ISO-8859-1
# lang-ru.rb
# @Author:      Thomas Link (micathom AT gmail com)
# @License:     GPL (see http://www.gnu.org/licenses/gpl.txt)
# @Created:     2007-01-04.
# @Last Change: 2008-12-04.
# @Revision:    0.3

require 'deplate/mod/lang-ru-koi8-r'

