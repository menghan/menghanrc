# encoding: ISO-8859-1
# builtin.rb
# @Author:      Thomas Link (micathom AT gmail com)
# @Website:     http://deplate.sf.net/
# @License:     GPL (see http://www.gnu.org/licenses/gpl.txt)
# @Created:     05-Jun-2004.
# @Last Change: 2008-12-04.
# @Revision:    0.5
# 
# Description:
# Dummy file

